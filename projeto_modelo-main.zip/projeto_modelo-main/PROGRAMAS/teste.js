n=5
fatorial=1
while (n>=1){
    fatorial=fatorial*n
    n=n-1
}
console.log(fatorial)